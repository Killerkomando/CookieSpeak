import type { FastifyInstance } from "fastify";
import type WebSocket from "ws";
import { WsClientEvent, type WsServerEvent } from "@tsa/shared";
import { prisma } from "./prisma.js";

type Conn = { ws: WebSocket; userId: string };
const connections = new Set<Conn>();

function send(ws: WebSocket, evt: WsServerEvent) {
  ws.send(JSON.stringify(evt));
}

export async function realtimeRoutes(app: FastifyInstance) {
  app.get("/ws", { websocket: true }, async (conn, req) => {
    const { token } = (req.query as any) ?? {};
    if (!token) return conn.socket.close(1008, "missing_token");

    try {
      const decoded = app.jwt.verify(token) as any;
      const userId = decoded.sub as string;

      const entry: Conn = { ws: conn.socket, userId };
      connections.add(entry);

      conn.socket.on("message", async (raw) => {
        let data: any;
        try {
          data = JSON.parse(raw.toString());
        } catch {
          return;
        }

        const evt = WsClientEvent.safeParse(data);
        if (!evt.success) return;

        if (evt.data.type === "CHAT:SEND") {
          const { channelId, content } = evt.data.payload;

          const channel = await prisma.channel.findUnique({ where: { id: channelId } });
          if (!channel) return;

          const membership = await prisma.membership.findFirst({
            where: { userId, workspaceId: channel.workspaceId },
          });
          if (!membership) return;

          const msg = await prisma.message.create({
            data: { channelId, userId, content },
          });

          const serverEvt: WsServerEvent = {
            type: "CHAT:MESSAGE_NEW",
            payload: {
              id: msg.id,
              channelId: msg.channelId,
              userId: msg.userId,
              content: msg.content,
              createdAt: msg.createdAt.toISOString(),
            },
          };

          for (const c of connections) send(c.ws, serverEvt);
        }
      });

      conn.socket.on("close", () => {
        connections.delete(entry);
      });
    } catch {
      conn.socket.close(1008, "invalid_token");
    }
  });
}
