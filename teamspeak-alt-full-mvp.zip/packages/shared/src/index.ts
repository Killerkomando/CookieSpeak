import { z } from "zod";

export const Id = z.string().min(8);

export const RegisterBody = z.object({
  email: z.string().email(),
  password: z.string().min(8).max(72),
});
export type RegisterBody = z.infer<typeof RegisterBody>;

export const LoginBody = RegisterBody;
export type LoginBody = z.infer<typeof LoginBody>;

export const CreateWorkspaceBody = z.object({
  name: z.string().min(2).max(64),
});
export type CreateWorkspaceBody = z.infer<typeof CreateWorkspaceBody>;

export const ChannelType = z.enum(["text", "voice"]);
export type ChannelType = z.infer<typeof ChannelType>;

export const CreateChannelBody = z.object({
  workspaceId: Id,
  name: z.string().min(1).max(64),
  type: ChannelType,
});
export type CreateChannelBody = z.infer<typeof CreateChannelBody>;

export const SendMessageBody = z.object({
  channelId: Id,
  content: z.string().min(1).max(4000),
});
export type SendMessageBody = z.infer<typeof SendMessageBody>;

export const WsClientEvent = z.discriminatedUnion("type", [
  z.object({ type: z.literal("CHAT:SEND"), payload: SendMessageBody }),
  z.object({ type: z.literal("VOICE:JOIN_REQUEST"), payload: z.object({ channelId: Id }) }),
  z.object({ type: z.literal("PRESENCE:SET_STATUS"), payload: z.object({ status: z.enum(["online", "away", "dnd"]) }) }),
]);
export type WsClientEvent = z.infer<typeof WsClientEvent>;

export const WsServerEvent = z.discriminatedUnion("type", [
  z.object({
    type: z.literal("CHAT:MESSAGE_NEW"),
    payload: z.object({
      id: Id,
      channelId: Id,
      userId: Id,
      content: z.string(),
      createdAt: z.string(),
    }),
  }),
  z.object({ type: z.literal("VOICE:JOIN_INFO"), payload: z.any() }),
  z.object({
    type: z.literal("PRESENCE:UPDATE"),
    payload: z.object({ userId: Id, status: z.string() }),
  }),
]);
export type WsServerEvent = z.infer<typeof WsServerEvent>;
